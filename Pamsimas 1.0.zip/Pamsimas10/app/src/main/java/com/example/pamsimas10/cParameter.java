package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class cParameter extends AppCompatActivity {

    EditText txtnopdam,txtnorayon,txtbulan,txttahun,txturl;
    ImageButton input,back;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c_parameter);
        txtnopdam = findViewById(R.id.kodepdam1);
        txtnorayon = findViewById(R.id.koderayon1);
        txtbulan = findViewById(R.id.bulan1);
        txttahun = findViewById(R.id.tahun1);
        txturl = findViewById(R.id.alamatserver1);
        input = findViewById(R.id.btninputparameter);
        db = new DatabaseHelper(this);
        back = findViewById(R.id.backparameter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(cParameter.this,Menu.class);
                startActivity(i);
            }
        });
        input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String kodePdam = txtnopdam.getText().toString();
                String kodeRayon = txtnorayon.getText().toString();
                String bulan = txtbulan.getText().toString();
                String tahun = txttahun.getText().toString();
                String url = txturl.getText().toString();

                if(kodePdam.equals("")&&kodeRayon.equals("")&&bulan.equals("")&&url.equals("")&&tahun.equals("")){
                    Toast.makeText(getApplicationContext(),"Lengkapi data anda",Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean check = db.checkKodePdam(kodePdam);
                    if(check==true){
                        Boolean check2 = db.checkKodeRayon(kodeRayon);
                        if(check2==true){
                            Boolean ins = db.insert2(kodePdam,kodeRayon,bulan,tahun,url);
                            if(ins==true){
                                Toast.makeText(getApplicationContext(),"Input data berhasil",Toast.LENGTH_SHORT).show();
                                txtnopdam.setText("");
                                txtnorayon.setText("");
                                txtbulan.setText("");
                                txttahun.setText("");
                                txturl.setText("");
                            }
                            else {
                                Toast.makeText(getApplicationContext(),"Terjadi kesalahan",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Kode Rayon sudah digunakan",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Kode PDAM sudah digunakan",Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });
    }
}
