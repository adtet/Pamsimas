package com.example.pamsimas10;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter2 extends RecyclerView.Adapter<RecyclerViewAdapter2.ViewHolder> {
    private ArrayList noPelangganlist;
    private ArrayList namaPelangganlist;
    private ArrayList awallist;
    private ArrayList akhirlist;
    private ArrayList usernamelist;
    private ArrayList tgllist;
    Context context;
    RecyclerViewAdapter2(ArrayList noPelangganlist,ArrayList namaPelangganlist,ArrayList awallist,ArrayList akhirlist,ArrayList usernamelist,ArrayList tgllist,Context context){
        this.noPelangganlist = noPelangganlist;
        this.namaPelangganlist = namaPelangganlist;
        this.awallist = awallist;
        this.akhirlist = akhirlist;
        this.usernamelist = usernamelist;
        this.tgllist = tgllist;
        this.context = context;
    }
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.showdata2,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final String nopelanggan = (String)noPelangganlist.get(position);
        final String namapelanggan = (String)namaPelangganlist.get(position);
        final String awal = (String)awallist.get(position);
        final String akhir = (String)akhirlist.get(position);
        final String username = (String)usernamelist.get(position);
        final String tgl = (String)tgllist.get(position);
        holder.txtnopelanggan.setText(nopelanggan);
        holder.txtnamapelanggan.setText(namapelanggan);
        holder.txtawal.setText(awal);
        holder.txtakhir.setText(akhir);
        holder.txtusername.setText(username);
        holder.txttgl.setText(tgl);
        holder.constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context,DetailData.class);
                i.putExtra("noPelanggan",nopelanggan);
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return namaPelangganlist.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txtnopelanggan,txtnamapelanggan,txtawal,txtakhir,txtusername,txttgl;
        ConstraintLayout constraintLayout;
        ViewHolder(View view){
            super(view);
            txtnopelanggan = view.findViewById(R.id.txtnoPelangganDp);
            txtnamapelanggan = view.findViewById(R.id.txtnamaDp);
            txtawal = view.findViewById(R.id.txtawalDp);
            txtakhir = view.findViewById(R.id.txtakhirDp);
            txtusername = view.findViewById(R.id.txtnameDp);
            txttgl = view.findViewById(R.id.txttglDp);
            constraintLayout = view.findViewById(R.id.constraint);
        }
    }
}
