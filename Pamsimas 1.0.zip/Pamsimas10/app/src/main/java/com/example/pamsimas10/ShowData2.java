package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import java.util.ArrayList;

public class ShowData2 extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList noPelangganlist;
    private ArrayList namaPelangganlist;
    private ArrayList awallist;
    private ArrayList akhirlist;
    private ArrayList usernamelist;
    private ArrayList tgllist;
    private DatabaseHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data2);
        noPelangganlist = new ArrayList<>();
        namaPelangganlist = new ArrayList<>();
        awallist = new ArrayList<>();
        akhirlist = new ArrayList<>();
        usernamelist = new ArrayList<>();
        tgllist = new ArrayList<>();
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler2);
        getData();
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerViewAdapter2(noPelangganlist,namaPelangganlist,awallist,akhirlist,usernamelist,tgllist,this);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.line));
        recyclerView.addItemDecoration(itemDecoration);

    }
    public void getData(){
        SQLiteDatabase read = db.getReadableDatabase();
        Cursor cursor = read.rawQuery("select * from tbtransaksi",null);
        cursor.moveToFirst();

        for(int i = 0;i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            noPelangganlist.add(cursor.getString(0));
            namaPelangganlist.add(cursor.getString(1));
            awallist.add(cursor.getString(2));
            akhirlist.add(cursor.getString(3));
            usernamelist.add(cursor.getString(10));
            tgllist.add(cursor.getString(11));

        }
    }
}
