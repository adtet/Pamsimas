package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.RelativeLayout;

import java.util.ArrayList;

public class ShowData extends AppCompatActivity {
    private DatabaseHelper db;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList kodePdamlist;
    private ArrayList noPelangganlist;
    private ArrayList namaPelangganlist;
    private ArrayList angkaAwallist;
    private ArrayList angkaAkhirlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);
        kodePdamlist = new ArrayList<>();
        noPelangganlist = new ArrayList<>();
        namaPelangganlist = new ArrayList<>();
        angkaAwallist = new ArrayList<>();
        angkaAkhirlist = new ArrayList<>();
        db = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recycler);
        getData();
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        adapter = new RecyclerViewAdapter(kodePdamlist,noPelangganlist,namaPelangganlist,angkaAwallist,angkaAkhirlist);
        recyclerView.setAdapter(adapter);
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.line));
        recyclerView.addItemDecoration(itemDecoration);

    }
    protected void getData(){
        SQLiteDatabase readData = db.getReadableDatabase();
        Cursor cursor = readData.rawQuery("select * from tbpelanggan",null);
        cursor.moveToFirst();

        for(int i = 0;i<cursor.getCount();i++){
            cursor.moveToPosition(i);
            kodePdamlist.add(cursor.getString(0));
            noPelangganlist.add(cursor.getString(1));
            namaPelangganlist.add(cursor.getString(2));
            angkaAwallist.add(cursor.getString(3));
            angkaAkhirlist.add(cursor.getString(4));
        }


    }
}
