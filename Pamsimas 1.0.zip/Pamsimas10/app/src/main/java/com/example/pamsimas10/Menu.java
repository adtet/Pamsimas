package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Menu extends AppCompatActivity {

    ImageButton btncp,btnpelanggan,btninputpelanggan,btncatat,btnmap,btntransaksi;
    Button exit;
    DatabaseHelper db;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        btncp = findViewById(R.id.btncatatmeter);
        btnpelanggan = findViewById(R.id.btndatapelanggan);
        exit = (Button)findViewById(R.id.btnexit);
        btninputpelanggan = (ImageButton)findViewById(R.id.inputpelanggan);
        btnmap = findViewById(R.id.btnmap);
        btncatat = findViewById(R.id.btndeteksi);
        btntransaksi = findViewById(R.id.btntransaksi);
        btntransaksi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ShowData2.class));
            }
        });
        btnmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,MapPoint.class);
                startActivity(i);
            }
        });
        btncatat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,Deteksimeteran.class);
                startActivity(i);
            }
        });
        btninputpelanggan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,pelanggan.class);
                startActivity(i);
            }
        });
        btncp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,cParameter.class);
                startActivity(i);
            }
        });
        btnpelanggan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Menu.this,ShowData.class);
                startActivity(i);
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                db.delete(db.username());
            }
        });



    }
}
