package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.Calendar;
import java.util.GregorianCalendar;

import android.widget.Toast;

import com.google.android.gms.location.LocationListener;
import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class Deteksimeteran extends AppCompatActivity implements LocationListener {
    DatabaseHelper db;
    Login lg;
    Calendar kalender = new GregorianCalendar();
    LocationManager locationManager;
    MapPoint mp;
    Location location;
    Context context;
    String provider,tgl;
    int bulan,tahun;
    public static EditText txtnopelanggan,txtakhir;
    ImageButton btnscan,btncari,btnreset,btninput,btnkemenu;
    public static TextView txtlatitude,txtlongitude,txtnama,txtawal;
    private static final int REQUEST_CODE = 101;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deteksimeteran);
        db = new DatabaseHelper(this);
        mp = new MapPoint();
        lg = new Login();
        txtnopelanggan = findViewById(R.id.txtnopelangganCAM);
        txtnama = findViewById(R.id.txtnamapelangganCAM);
        txtawal = findViewById(R.id.txtawalCAM);
        txtakhir = findViewById(R.id.txtakhirCAM);
        txtlatitude = findViewById(R.id.txtlatCAM);
        txtlongitude = findViewById(R.id.txtlongCAM);
        btnscan = findViewById(R.id.btnscanCAM);
        btncari = findViewById(R.id.btncariCAM);
        btnreset = findViewById(R.id.btnresetCAM);
        btninput = findViewById(R.id.btninputCAM);
        btnkemenu = findViewById(R.id.btnkemenu);
        locationManager = (LocationManager)this.getSystemService(Context.LOCATION_SERVICE);
        Criteria cf = new Criteria();
        bulan = kalender.get(Calendar.MONTH)+1;
        tahun = kalender.get(Calendar.YEAR);
        int date = kalender.get(Calendar.DATE);
        tgl = String.valueOf(tahun)+String.valueOf(bulan)+String.valueOf(date);
        provider = locationManager.getBestProvider(cf,false);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String []{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        location = locationManager.getLastKnownLocation(provider);
        if(location!=null) {
            double lng = location.getLongitude();
            double lat = location.getLatitude();
            String slng = String.valueOf(lng);
            String slat = String.valueOf(lat);
            txtlongitude.setText(slng);
            txtlatitude.setText(slat);
        }
        else{
            txtlongitude.setText("deny");
            txtlatitude.setText("deny");
        }
        btnkemenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Deteksimeteran.this,Menu.class));
            }
        });
        btninput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String noPelanggan = txtnopelanggan.getText().toString();
                String nama = txtnama.getText().toString();
                String awal = txtawal.getText().toString();
                int AWAL = Integer.parseInt(awal);
                String akhir = txtakhir.getText().toString();
                int AKHIR = Integer.parseInt(akhir);
                String kodePdam = db.kodePdam();
                String kodeRayon = db.kodeRayon();
                String longi = txtlongitude.getText().toString();
                String lat = txtlatitude.getText().toString();
                String sbulan = String.valueOf(bulan);
                String stahun = String.valueOf(tahun);
                String username = db.username();
                String tanggal = tgl;

                if(AWAL>AKHIR){
                    Toast.makeText(getApplicationContext(),"cek angka awal dan akhir",Toast.LENGTH_SHORT).show();
                }
                else {
                    Boolean ins = db.insert4(noPelanggan,nama,awal,akhir,kodePdam,kodeRayon,longi,lat,sbulan,stahun,username,tanggal);
                    if(ins==true){
                        Toast.makeText(getApplicationContext(),"Input data berhasil",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Input data gagal",Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtnopelanggan.setText("");
                txtnama.setText("");
                txtawal.setText("");
                txtakhir.setText("");
            }
        });
        btncari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String b = txtnopelanggan.getText().toString();
                String c = db.nama_pelanggan(b);
                String e = db.angka_awal(b);
                txtnama.setText(c);
                txtawal.setText(e);

            }
        });
        btnscan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ScannerQR.class));
            }
        });
    }
    @Override
    public void onLocationChanged(Location location) {
        double lng = location.getLongitude();
        double lat = location.getLatitude();
        String slng = String.valueOf(lng);
        String slat = String.valueOf(lat);
        txtlongitude.setText(slng);
        txtlatitude.setText(slat);
    }
}
