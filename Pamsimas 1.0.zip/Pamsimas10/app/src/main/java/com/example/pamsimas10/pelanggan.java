package com.example.pamsimas10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class pelanggan extends AppCompatActivity {
    DatabaseHelper db;
    Button btninput;
    EditText txtkodePdam,txtnopelanggan,txtnamapelanggan,txtangkaawal,txtangkaahir;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pelanggan);
        txtkodePdam = findViewById(R.id.kodePdamcoba);
        txtnopelanggan = findViewById(R.id.nopelanggancoba);
        txtnamapelanggan = findViewById(R.id.namapelanggancoba);
        txtangkaawal = findViewById(R.id.angkaawalcoba);
        txtangkaahir = findViewById(R.id.angkaakhircoba);
        btninput = findViewById(R.id.btninputcobapelanggan);
        db = new DatabaseHelper(this);
        btninput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String kodePdam = txtkodePdam.getText().toString();
                String noPelanggan = txtnopelanggan.getText().toString();
                String namaPelanggan = txtnamapelanggan.getText().toString();
                String angkaAwal = txtangkaawal.getText().toString();
                String angkaAkhir = txtangkaahir.getText().toString();

                Boolean ins = db.insert3(kodePdam,noPelanggan,namaPelanggan,angkaAwal,angkaAkhir);
                if(ins==true){
                    Toast.makeText(getApplicationContext(),"Data masuk",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
