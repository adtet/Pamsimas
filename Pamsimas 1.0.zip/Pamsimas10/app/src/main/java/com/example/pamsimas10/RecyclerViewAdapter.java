package com.example.pamsimas10;
import android.accessibilityservice.GestureDescription;
import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList KodePdamList;
    private ArrayList noPelangganList;
    private ArrayList namaPelangganList;
    private ArrayList angkaAwalList;
    private ArrayList angkaAkhirList;

    RecyclerViewAdapter(ArrayList kodePdamlist, ArrayList noPelangganlist, ArrayList namaPelangganlist, ArrayList angkaAwallist, ArrayList angkaAkhirlist){
        this.KodePdamList = kodePdamlist;
        this.noPelangganList = noPelangganlist;
        this.namaPelangganList = namaPelangganlist;
        this.angkaAwalList = angkaAwallist;
        this.angkaAkhirList = angkaAkhirlist;
    }
    class ViewHolder extends RecyclerView.ViewHolder{
        private TextView mKodePdam,mnoPelanggan,mnamaPelanggan,mangkaAwal,mangkaAkhir;

        ViewHolder(View itemView){
            super(itemView);
            mKodePdam = itemView.findViewById(R.id.kodePdamR);
            mnoPelanggan = itemView.findViewById(R.id.noPelangganR);
            mnamaPelanggan = itemView.findViewById(R.id.namaPelangganR);
            mangkaAwal = itemView.findViewById(R.id.angkaAwalR);
            mangkaAkhir = itemView.findViewById(R.id.angkaAkhirR);

        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.showdata,parent,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final String KodePdam = (String) KodePdamList.get(position);
        final String noPelanggan = (String) noPelangganList.get(position);
        final String namaPelanggan = (String)namaPelangganList.get(position);
        final String angkaAwal = (String)angkaAwalList.get(position);
        final String angkaAkhir = (String)angkaAkhirList.get(position);
        holder.mKodePdam.setText(KodePdam);
        holder.mnoPelanggan.setText(noPelanggan);
        holder.mnamaPelanggan.setText(namaPelanggan);
        holder.mangkaAwal.setText(angkaAwal);
        holder.mangkaAkhir.setText(angkaAkhir);


    }

    @Override
    public int getItemCount() {
        return KodePdamList.size();
    }

}
